"""
Routes and views for the flask application.
"""

from flask import *
from login import app



@app.route('/')
@app.route('/login')
def home():
    """Renders the home page."""
    return render_template('layout.html')
   


@app.route('/index', methods=['POST'])
def login():
    """Renders the login success page."""
    if request.form["password"] == 'passwd' and request.form["username"] == 'admin01':
        return render_template('Index.html')
    else:
        return redirect('/login')
        flash("Username or password is incorrect")

